import { NextResponse } from "next/server";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";

export const runtime = "nodejs";

const region = process.env.AWS_REGION!;
const tableName = process.env.DDB_TABLE_NAME!;
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({ region }));

function normalizeSet(set: string | null): "CENTER" | "SLIDES" | "BACKGROUND" | null {
  if (!set) return null;
  const s = set.trim().toUpperCase();
  if (s === "CENTER") return "CENTER";
  if (s === "SLIDES") return "SLIDES";
  if (s === "BACKGROUND") return "BACKGROUND";
  if (s === "BG") return "BACKGROUND"; // backward compat
  return null;
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const set = normalizeSet(url.searchParams.get("set"));
  if (!set) {
    return NextResponse.json(
      { error: "Missing/invalid set. Use ?set=CENTER|SLIDES|BACKGROUND" },
      { status: 400 }
    );
  }

  try {
    const out = await ddb.send(
      new QueryCommand({
        TableName: tableName,
        KeyConditionExpression: "pk = :pk",
        ExpressionAttributeValues: { ":pk": set },
      })
    );

    const items = (out.Items || [])
      .map((it: any) => ({
        pk: it.pk,
        sk: it.sk,
        url: it.url,
        mediaType: it.mediaType || "",
        enabled: it.enabled !== false,
        order: Number(it.order ?? 0),
        category1: it.category1 ?? "",
        category2: it.category2 ?? "",
        description: it.description ?? "",
        createdAt: it.createdAt,
      }))
      .filter((x) => x.url && x.enabled)
      .sort(
        (a, b) =>
          (a.order - b.order) ||
          String(a.sk).localeCompare(String(b.sk))
      );

    return NextResponse.json({ ok: true, set, items });
  } catch (e: any) {
    return NextResponse.json(
      { error: "DDB read failed", detail: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}
