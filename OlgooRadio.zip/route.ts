import { NextResponse } from "next/server";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

export const runtime = "nodejs";

function requireAdmin(req: Request) {
  const token = (req.headers.get("x-admin-token") || "").trim();
  return !!process.env.ADMIN_TOKEN && token === process.env.ADMIN_TOKEN;
}

type SetKind = "CENTER" | "SLIDES" | "BG";

const region = process.env.AWS_REGION!;
const bucket = process.env.S3_BUCKET_NAME!; // must be set in .env.local
const s3 = new S3Client({ region });

function badRequest(message: string) {
  return NextResponse.json({ error: message }, { status: 400 });
}

function isAllowed(set: SetKind, contentType: string) {
  const ct = (contentType || "").toLowerCase();

  if (set === "CENTER") return ct === "video/mp4";
  if (set === "SLIDES") return ct.startsWith("image/");
  if (set === "BG") return ct.startsWith("image/") || ct === "video/mp4";

  return false;
}

export async function GET(req: Request) {
  if (!requireAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!bucket) return NextResponse.json({ error: "Missing S3_BUCKET_NAME in env" }, { status: 500 });

  const url = new URL(req.url);
  const set = url.searchParams.get("set") as SetKind | null;
  const filename = (url.searchParams.get("filename") || "").trim();
  const contentType = (url.searchParams.get("contentType") || "").trim();

  if (!set || !["CENTER", "SLIDES", "BG"].includes(set)) {
    return badRequest("Missing/invalid set. Use ?set=CENTER or ?set=SLIDES or ?set=BG");
  }
  if (!filename) return badRequest("Missing filename");
  if (!contentType) return badRequest("Missing contentType");

  if (!isAllowed(set, contentType)) {
    return badRequest(
      set === "CENTER"
        ? "CENTER accepts only video/mp4"
        : set === "SLIDES"
        ? "SLIDES accepts only image/*"
        : "BG accepts image/* or video/mp4"
    );
  }

  // Build an S3 key:  <SET>/<timestamp>-<sanitized filename>
  const safeName = filename.replace(/[^a-zA-Z0-9._-]/g, "_");
  const key = `${set}/${Date.now()}-${safeName}`;

  try {
    const cmd = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      ContentType: contentType,
      // Optional but good for browser uploads:
      CacheControl: "public, max-age=31536000, immutable",
    });

    const uploadUrl = await getSignedUrl(s3, cmd, { expiresIn: 300 });

    // IMPORTANT: public URL must use your real bucket name (NOT "undefined")
    const publicUrl = `https://${bucket}.s3.${region}.amazonaws.com/${key}`;

    return NextResponse.json({ ok: true, set, key, uploadUrl, publicUrl });
  } catch (e: any) {
    return NextResponse.json(
      { error: "Presign failed", detail: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}
