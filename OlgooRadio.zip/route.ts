import { NextResponse } from "next/server";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  PutCommand,
  DeleteCommand,
  QueryCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";

export const runtime = "nodejs";

function requireAdmin(req: Request) {
  const token = (req.headers.get("x-admin-token") || "").trim();
  return !!process.env.ADMIN_TOKEN && token === process.env.ADMIN_TOKEN;
}

const region = process.env.AWS_REGION!;
const tableName = process.env.DDB_TABLE_NAME!;
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({ region }));

type SetKind = "CENTER" | "SLIDES" | "BG";

function badRequest(message: string) {
  return NextResponse.json({ error: message }, { status: 400 });
}

function normalizeSet(v: any): SetKind | null {
  const s = String(v || "").trim().toUpperCase();
  if (s === "CENTER" || s === "SLIDES" || s === "BG") return s as SetKind;
  return null;
}

function validateMedia(set: SetKind, mediaType: string) {
  const mt = (mediaType || "").toLowerCase();

  if (set === "CENTER") return mt === "video/mp4";
  if (set === "SLIDES") return mt.startsWith("image/");
  if (set === "BG") return mt.startsWith("image/") || mt === "video/mp4";
  return false;
}

export async function GET(req: Request) {
  if (!requireAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const url = new URL(req.url);
  const set = normalizeSet(url.searchParams.get("set"));

  if (!set) return badRequest("Missing/invalid set. Use ?set=CENTER or ?set=SLIDES or ?set=BG");

  try {
    const out = await ddb.send(
      new QueryCommand({
        TableName: tableName,
        KeyConditionExpression: "pk = :pk",
        ExpressionAttributeValues: { ":pk": set },
      })
    );

    const items = (out.Items || []).map((it: any) => ({
      pk: it.pk,
      sk: it.sk,
      url: it.url,
      mediaType: it.mediaType || "",
      enabled: it.enabled !== false,
      order: Number(it.order ?? 0),
      category1: it.category1 || "",
      category2: it.category2 || "",
      description: it.description || "",
      createdAt: it.createdAt,
    }));

    items.sort(
      (a, b) =>
        (a.order - b.order) ||
        String(a.sk).localeCompare(String(b.sk))
    );

    return NextResponse.json({ ok: true, set, items });
  } catch (e: any) {
    return NextResponse.json(
      { error: "DDB read failed", detail: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  if (!requireAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  let body: any;
  try {
    body = await req.json();
  } catch {
    return badRequest("Body must be valid JSON");
  }

  const set = normalizeSet(body?.set);
  const url = String(body?.url || "").trim();
  const mediaType = String(body?.mediaType || "").trim();

  if (!set) return badRequest("Invalid set. Must be CENTER or SLIDES or BG");
  if (!url) return badRequest("Missing url");
  if (!mediaType) return badRequest("Missing mediaType");
  if (!validateMedia(set, mediaType)) {
    return badRequest(
      set === "CENTER"
        ? "CENTER accepts only video/mp4"
        : set === "SLIDES"
        ? "SLIDES accepts only image/*"
        : "BG accepts image/* or video/mp4"
    );
  }

  const order = typeof body.order === "number" ? body.order : 0;
  const enabled = typeof body.enabled === "boolean" ? body.enabled : true;
  const category1 = String(body.category1 || "");
  const category2 = String(body.category2 || "");
  const description = String(body.description || "");

  const skPrefix = mediaType.startsWith("video/") ? "VID" : "IMG";
  const sk = `${skPrefix}#${Date.now()}#${Math.random().toString(16).slice(2)}`;

  try {
    // Optional: if BG should keep ONLY ONE ACTIVE, disable others first
    if (set === "BG" && enabled) {
      const existing = await ddb.send(
        new QueryCommand({
          TableName: tableName,
          KeyConditionExpression: "pk = :pk",
          ExpressionAttributeValues: { ":pk": "BG" },
        })
      );

      const toDisable = (existing.Items || []).filter((x: any) => x.enabled !== false);
      for (const it of toDisable) {
        await ddb.send(
          new UpdateCommand({
            TableName: tableName,
            Key: { pk: "BG", sk: it.sk },
            UpdateExpression: "SET enabled = :f",
            ExpressionAttributeValues: { ":f": false },
          })
        );
      }
    }

    await ddb.send(
      new PutCommand({
        TableName: tableName,
        Item: {
          pk: set,
          sk,
          url,
          mediaType,
          enabled,
          order,
          category1,
          category2,
          description,
          createdAt: new Date().toISOString(),
        },
      })
    );

    return NextResponse.json({ ok: true, pk: set, sk }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { error: "DDB write failed", detail: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  if (!requireAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const url = new URL(req.url);
  const set = normalizeSet(url.searchParams.get("set"));
  const sk = url.searchParams.get("sk");

  if (!set) return badRequest("Missing/invalid set. Use ?set=CENTER or ?set=SLIDES or ?set=BG");
  if (!sk) return badRequest("Missing sk. Use ?sk=IMG#... or VID#...");

  try {
    await ddb.send(
      new DeleteCommand({
        TableName: tableName,
        Key: { pk: set, sk },
      })
    );

    return NextResponse.json({ ok: true, deleted: { pk: set, sk } });
  } catch (e: any) {
    return NextResponse.json(
      { error: "Delete failed", detail: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}
