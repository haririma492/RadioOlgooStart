# Admin drop-in (only)

Unzip and copy the `app/` folder into your existing project root, merging folders.

Adds:
- /admin page (upload images)
- /api/admin/presign (S3 presigned PUT)
- /api/admin/slides (DynamoDB register)

Required env vars (server):
AWS_REGION
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
DDB_TABLE_NAME
S3_BUCKET
ADMIN_TOKEN

Required env var (client):
NEXT_PUBLIC_S3_PUBLIC_BASE   (S3 or CloudFront base URL)

Dependencies:
npm i @aws-sdk/client-s3 @aws-sdk/s3-request-presigner
