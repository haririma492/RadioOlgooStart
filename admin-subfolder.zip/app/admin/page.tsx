"use client";

import React, { useState } from "react";

type SlideSet = "CENTER" | "BG";

function extFromName(name: string) {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i + 1).toLowerCase() : "bin";
}

export default function AdminPage() {
  const [token, setToken] = useState("");
  const [setName, setSetName] = useState<SlideSet>("CENTER");
  const [files, setFiles] = useState<File[]>([]);
  const [log, setLog] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  function addLog(line: string) {
    setLog((x) => [line, ...x].slice(0, 50));
  }

  async function uploadAll() {
    if (!token) {
      addLog("Missing ADMIN_TOKEN (enter it at top).");
      return;
    }
    if (files.length === 0) {
      addLog("No files selected.");
      return;
    }

    const baseUrl = process.env.NEXT_PUBLIC_S3_PUBLIC_BASE || "";
    if (!baseUrl) {
      addLog("Missing NEXT_PUBLIC_S3_PUBLIC_BASE in env vars.");
      return;
    }

    setBusy(true);
    try {
      for (const f of files) {
        const safeName = f.name.replace(/[^\w.\-]+/g, "_");
        const key = `${setName}/${Date.now()}-${Math.random().toString(16).slice(2)}.${extFromName(safeName)}`;

        // 1) presign upload
        const pres = await fetch("/api/admin/presign", {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-admin-token": token },
          body: JSON.stringify({ filename: safeName, contentType: f.type || "application/octet-stream", key }),
        });
        const presJson = await pres.json();
        if (!pres.ok) throw new Error(presJson?.error || "Presign error");
        const uploadUrl = presJson.uploadUrl as string;

        // 2) upload to S3
        const put = await fetch(uploadUrl, {
          method: "PUT",
          headers: { "Content-Type": f.type || "application/octet-stream" },
          body: f,
        });
        if (!put.ok) throw new Error(`S3 upload failed for ${f.name}`);

        // 3) register in DynamoDB
        const url = `${baseUrl.replace(/\/$/, "")}/${key}`;
        const reg = await fetch("/api/admin/slides", {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-admin-token": token },
          body: JSON.stringify({ set: setName, url, order: 0 }),
        });
        const regJson = await reg.json();
        if (!reg.ok) throw new Error(regJson?.error || "DDB register error");

        addLog(`✅ Uploaded + registered: ${f.name} → ${setName}`);
      }
      setFiles([]);
    } catch (e: any) {
      addLog(`❌ ${e?.message ?? String(e)}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ padding: 24, maxWidth: 880, margin: "0 auto", fontFamily: "Arial, sans-serif" }}>
      <h1>Radio Olgoo Admin</h1>

      <div style={{ display: "grid", gap: 12, padding: 16, border: "1px solid #333", borderRadius: 12 }}>
        <label style={{ display: "grid", gap: 6 }}>
          <div>Admin token</div>
          <input
            type="password"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            placeholder="Paste ADMIN_TOKEN here"
            style={{ padding: 10, borderRadius: 10 }}
          />
        </label>

        <label style={{ display: "grid", gap: 6 }}>
          <div>Slide set</div>
          <select
            value={setName}
            onChange={(e) => setSetName(e.target.value as SlideSet)}
            style={{ padding: 10, borderRadius: 10 }}
          >
            <option value="CENTER">CENTER (middle slideshow)</option>
            <option value="BG">BG (wallpaper background)</option>
          </select>
        </label>

        <label style={{ display: "grid", gap: 6 }}>
          <div>Choose photos</div>
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
          />
        </label>

        <button
          onClick={uploadAll}
          disabled={busy}
          style={{ padding: "12px 14px", borderRadius: 12, cursor: busy ? "not-allowed" : "pointer" }}
        >
          {busy ? "Uploading..." : "Upload to S3 + Register in DynamoDB"}
        </button>

        <div style={{ fontSize: 12, opacity: 0.8 }}>
          Requires env var: NEXT_PUBLIC_S3_PUBLIC_BASE (S3 or CloudFront base URL).
        </div>
      </div>

      <h3 style={{ marginTop: 18 }}>Log</h3>
      <div
        style={{
          whiteSpace: "pre-wrap",
          fontFamily: "Consolas, monospace",
          fontSize: 12,
          border: "1px solid #333",
          borderRadius: 12,
          padding: 12,
        }}
      >
        {log.length ? log.join("\n") : "No actions yet."}
      </div>
    </div>
  );
}
