import { NextResponse } from "next/server";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

export const runtime = "nodejs";

function requireAdmin(req: Request) {
  const token = req.headers.get("x-admin-token") || "";
  return !!process.env.ADMIN_TOKEN && token === process.env.ADMIN_TOKEN;
}

const region = process.env.AWS_REGION!;
const bucket = process.env.S3_BUCKET!;
const s3 = new S3Client({ region });

export async function POST(req: Request) {
  try {
    if (!requireAdmin(req)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { filename, contentType, key } = body as {
      filename: string;
      contentType: string;
      key: string;
    };

    if (!filename || !contentType || !key) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }

    const cmd = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      ContentType: contentType,
    });

    const uploadUrl = await getSignedUrl(s3, cmd, { expiresIn: 60 });
    return NextResponse.json({ uploadUrl }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { error: "Presign failed", detail: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}
