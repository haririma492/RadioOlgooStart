import { NextResponse } from "next/server";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, DeleteCommand } from "@aws-sdk/lib-dynamodb";

export const runtime = "nodejs";

function requireAdmin(req: Request) {
  const token = req.headers.get("x-admin-token") || "";
  return !!process.env.ADMIN_TOKEN && token === process.env.ADMIN_TOKEN;
}

const region = process.env.AWS_REGION!;
const tableName = process.env.DDB_TABLE_NAME!;
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({ region }));

type SetKind = "CENTER" | "BG";

export async function POST(req: Request) {
  try {
    if (!requireAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { set, url, order } = (await req.json()) as { set: SetKind; url: string; order?: number };
    if (!set || !url) return NextResponse.json({ error: "Missing set/url" }, { status: 400 });
    if (set !== "CENTER" && set !== "BG") return NextResponse.json({ error: "Invalid set" }, { status: 400 });

    const sk = `IMG#${Date.now()}#${Math.random().toString(16).slice(2)}`;
    await ddb.send(
      new PutCommand({
        TableName: tableName,
        Item: {
          pk: set,
          sk,
          url,
          enabled: true,
          order: typeof order === "number" ? order : 0,
          createdAt: new Date().toISOString(),
        },
      })
    );

    return NextResponse.json({ ok: true, pk: set, sk }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { error: "DDB write failed", detail: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  try {
    if (!requireAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { pk, sk } = (await req.json()) as { pk: SetKind; sk: string };
    if (!pk || !sk) return NextResponse.json({ error: "Missing pk/sk" }, { status: 400 });

    await ddb.send(new DeleteCommand({ TableName: tableName, Key: { pk, sk } }));
    return NextResponse.json({ ok: true }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json({ error: "Delete failed", detail: e?.message ?? String(e) }, { status: 500 });
  }
}
